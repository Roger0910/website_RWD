//111216044 歐泓毅
//使用者輸入四個不重複數字後，程式會告訴使用者跟正確答案的關係是幾A幾B，直到10次後會直接彈出答案，若是正確則會寫花了幾次
//程式有意義且可以執行 (+20%)，完成遊戲 (+70%)，給自己評90分，該有的東西都有，就是不確定是不是一定要照著題目給的輸入輸出範例寫，比如說我想加個描述好讓使用者知道該怎麼做的話會不會有問題

import java.util.*;

public class H3_111216044 {
    public static void main(String[] args) { 
        Scanner scn = new Scanner(System.in);

        Set<Integer> uniqueNumbers = new HashSet<>();
        Random random = new Random();

        // 生成 4 個不重複的隨機數字
        while (uniqueNumbers.size() < 4) {
            int number = random.nextInt(10); // 生成 0 到 9 的隨機數字
            uniqueNumbers.add(number);
        }

        // 將 Set 轉換為陣列
        int[] questions = new int[4];
        int index = 0;
        for (int num : uniqueNumbers) {
            questions[index++] = num;
        }
        
        System.out.println("請輸入四個不重複數字(不用空格)");
        
        int e=0;
        while (e<10) { //若答題的次數小於10就重複執行
            int[] array = new int[4];
            int a,b,c,d;
            int answer=scn.nextInt();
            a = answer/1000;
            array[0]=a;
            b = (answer-a*1000)/100;
            array[1]=b;
            c = (answer-(a*1000+b*100))/10;
            array[2]=c;
            d = answer%10;
            array[3]=d;
            
            int A=0,B=0;
            for(int i = 0; i < array.length; i++){//將使用者輸入的答案與題目做對比，數字和位置都正確則a+1
                if(array[i]==questions[i]){
                        A=A+1;
                }else{
                    for (int j = 0; j < array.length;j++) {//若位置不正確而數字正確則b+1
                        if(array[i]==questions[j] && array[i]!=questions[i]){
                            B=B+1;
                        }
                    }
                }
                
            }
            System.out.println(A+"A"+B+"B");
            System.out.println(" ");
            e=e+1;
            if (A==4) {//判斷使用者輸入的答案正不正確，若正確則跳出迴圈
                break;
            }
        }
        
        if(e==10){//判斷次數是否為10，若不是則說明使用者成功答對
            System.out.println("挑戰次數達到上限，正確答案為");
            for (int num : questions) {//超過次數後輸出答案
            System.out.print(num);
            }
        }else{
            System.out.println("恭喜答對");
            System.out.println("你一共用了"+e+"次");
        }
    }
}