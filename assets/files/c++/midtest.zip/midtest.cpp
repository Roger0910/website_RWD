#include<iostream>
#include<cstring>
using namespace std;

class node{
	int no;
	node *ptr;
	char name[10];
	int prg;
	int cmp;
public:
	void writeno(int a){
		no=a;
	}
	int readno(){
		return no;
	}
	void writeptr(node *b){
		ptr=b;
	}
	node *readptr(){
		return ptr;
	}
	void writename(char *c){
		for(int i=0; i<20 ;i++){
			name[i] = c[i];
		}
	}
	char *readname(){
		return name;
	}
	void writeprg(int d){
		prg=d;
	}
	int readprg(){
		return prg;
	}
	void writecmp(int e){
		cmp=e;
	}
	int readcmp(){
		return cmp;
	}
};

class MENU{
	int select;
public:
	void show(){
		cout<<"Menu"<<endl;
		cout<<"1. create new no."<<endl;
		cout<<"2. search no."<<endl;
		cout<<"3. delect no."<<endl;
		cout<<"4. transcript"<<endl;
		cout<<"0. exit"<<endl;
		cout<<"Please select a choice"<<endl;
	}
	void sel(){
		cin>>select;
	}
	int showsel(){
		return select;
	}
	void menu(){
		select = 1;
	}
};

void printlist(node *p){
	cout<<"head"<<"->";
	while(p){
		cout<<p->readno()<<"->";
		p=p->readptr();
	}
	cout<<"//"<<endl;
} 

void transcript(node *head) {
    if (head == NULL || head->readptr() == NULL) {
        cout << "List is empty or contains only one element. No sorting needed." << endl;
        return;
    }

    int count = 0;
    node *p = head;
    while (p != NULL) {
        count++;
        p = p->readptr();
    }

    node *nodeArray[count];
    int i = 0;
    p = head;
    while (p != NULL) {
        nodeArray[i] = p;
        p = p->readptr();
        i++;
    }

    for (int i = 0; i < count - 1; i++) {
        for (int j = 0; j < count - i - 1; j++) {
            int sum1 = nodeArray[j]->readprg() + nodeArray[j]->readcmp();
            int sum2 = nodeArray[j + 1]->readprg() + nodeArray[j + 1]->readcmp();
            if (sum1 < sum2) {
                swap(nodeArray[j], nodeArray[j + 1]);
            }
            else if (sum1 == sum2) {
                // �p�G��?�ۦP�A?�ƦW�]�ۦP
                if (nodeArray[j]->readno() != nodeArray[j + 1]->readno()) {
                    // �p�G??���P�A?�ƦW��?
                    continue;
                }
            }
        }
    }

    cout << "Sorted list by prg + cmp:" << endl;
    int rank = 1; // ��l�ƱƦW?1
    for (int i = 0; i < count; i++) {
        cout << "Rank:" << rank << ", ";
        cout << "No.:" << nodeArray[i]->readno() << ", ";
        cout << "Name:" << nodeArray[i]->readname() << ", ";
        cout << "Prg:" << nodeArray[i]->readprg() << ", ";
        cout << "Cmp:" << nodeArray[i]->readcmp() << endl;

        // �p�G?�e??�M�U�@???����?���P�A�ƦW?�W
        if (i < count - 1 && (nodeArray[i]->readprg() + nodeArray[i]->readcmp() != nodeArray[i + 1]->readprg() + nodeArray[i + 1]->readcmp())) {
            rank = i + 2; // �U�@?�ƦW??�e�ƦW�Z��?��
        }
    }
}



int main(){
	node *head=NULL;
	node *p;
	node *q=NULL;
	int n=1,prg,cmp;
	char name[20];
	int select;

	MENU m;
	while(m.showsel()){
		m.show();
		m.sel();
		switch(m.showsel()){
			case 1:
				cout<<"You choise 1. create new no."<<endl;
				cout<<"Please input no.";
				n=1;
				{
					cin>>n;
					if(n>0){
						bool check=false;
						q=head;
  			        	while(q){
   			            	if(q->readno()==n) {
								check=true;
  			            		break;
   			            	}
               			q=q->readptr();
           				}
           				if(check){
               				cout<<"Please enter a different no."<<endl;
               				continue;
           				}
		
						cout<<"Please input name:";
						cin>>name;
						cout<<"Please input prg:";
						cin>>prg;
						cout<<"Please input cmp:";
						cin>>cmp;		
						if(head==0){
							p=new node;
							p->writeno(n);
							p->writeptr(head);
							p->writename(name);
							p->writeprg(prg);
							p->writecmp(cmp);
							head=p;
						}
						else if(n < head->readno()){
							p=new node;
							p->writeno(n);
							p->writeptr(head);
							p->writename(name);
							p->writeprg(prg);
							p->writecmp(cmp);
							head=p;
						}
						else{
							q=head;
							p=new node;
							p->writeno(n);
							p->writename(name);
							p->writeprg(prg);
							p->writecmp(cmp);
							while(n>= q->readno()){
								if(q->readptr() && n> q->readptr()->readno()){
									q=q->readptr();	
								}
					
								else{
									break;
								}
							}
			
							p->writeptr(q->readptr());
							q->writeptr(p);
						}
						printlist(head);
						cout<<"please input no.";
					}
					else{
						break;
					}
				}
				printlist(head);
				break;
			case 2:
				{
					if (head == NULL) {
        				cout << "No data yet." << endl;
        				break;
    				}
    				cout<<"You choise 2. find no."<<endl;
    				int search;
    				cout<<"Please input the no. you want to search:";
    				cin>>search;
    				p=head;
    				bool found=false;
    				while(p){
    				    if(p->readno() == search){
    				        found=true;
    				        cout<<"No.:"<<p->readno()<<endl;
    				        cout<<"Name:"<<p->readname()<<endl;
    				        cout<<"Prg:"<<p->readprg()<<endl;
    				        cout<<"Cmp:"<<p->readcmp()<<endl;
    				        break;
    				    }
    				    p = p->readptr();
    				}
    				if (!found) {
    				    cout << "No. not found!" << endl;
    				}
    				break;
				}
			case 3:
				{
					if (head == NULL) {
        				cout << "No data yet." << endl;
        				break;
    				}
				    cout<<"You choise 3. delete data."<<endl;
				    int deleteno;
				    cout<<"Please input the no. you want to delete:";
				    cin>>deleteno;    
				    node *pre=NULL;
				    p=head;
				    while(p){
				        if(p->readno()==deleteno){
				            if(pre){
				                pre->writeptr(p->readptr());
				            }
							else{
				                head=p->readptr();
				            }
				            delete p;
				            cout<<"Data deleted finished."<<endl;
				            break;
				        }
				        pre=p;
				        p=p->readptr();
				    }
				    if(!p){
				        cout<<"Data not found!"<<endl;
				    }
				    break;
				}
			case 4:
				cout << "You choose 4. transcript" << endl;
				transcript(head);
				break;
			case 0:
				cout<<"Have a nice day. Bye!"<<endl;
				break;
			default:
				cout<<"Please input correct number."<<endl;
				break;
		}
	}

}



